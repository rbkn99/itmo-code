package exceptions;

public class IllegalArgumentException extends Exception {
    public IllegalArgumentException() {
        super("illegal params for the program");
    }
}
