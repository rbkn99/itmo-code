package exceptions;

public class EvaluateException extends Exception {
    public EvaluateException(String message) {
        super(message);
    }
}
