package parser;

public enum TokenType {
    LP, RP, SUB, ADD, MUL, DIV, CONST, VAR, BEGIN, END, MINUS, MAX, MIN, COUNT
}
