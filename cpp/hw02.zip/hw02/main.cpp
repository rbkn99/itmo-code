#include <iostream>
#include <limits>
#include <cassert>
#include "big_integer.h"

int main() {
    //big_integer a = (-12 << 4);
    //auto b = a.__quotient(1 << 23);
    std::cout << (-12 << 4);
    return 0;
}